package Controller;

import Model.UsuarioModel;
import Repository.UsuarioRepository;

import java.sql.SQLException;

public class UsuarioController {
    private UsuarioRepository usuarioRepository = new UsuarioRepository();

    public String salvar(UsuarioModel usuario) throws SQLException {
        return usuarioRepository.salvar(usuario);
    }
    public String deletar(Long idUsuarioSelecionado) throws SQLException {
        UsuarioModel usuario = usuarioRepository.buscarPorId(idUsuarioSelecionado);
        return usuarioRepository.deletar(usuario);
    }
}
