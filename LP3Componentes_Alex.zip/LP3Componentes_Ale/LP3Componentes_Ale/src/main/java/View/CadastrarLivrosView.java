package View;

import Controller.LivroController;
import Model.LivroModel;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;

public class CadastrarLivrosView extends JFrame{
    private JPanel panel1;
    private JPanel JPaneCadastroLivros;
    private JTextField textFieldTitulo;
    private JTextField textFieldTema;
    private JTextField textFieldAutor;
    private JTextField textFieldIsbn;
    private JTextField textFieldQuantidade;
    private JButton buttonRetornar;
    private JButton buttonCadastrarLivro;
    private JFormattedTextField formattedTextFieldData;

    public CadastrarLivrosView() {
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(panel1);
        this.setSize(640, 480);
        this.setVisible(true);
        try {
            MaskFormatter data = new MaskFormatter("##/##/####");
            data.install(formattedTextFieldData);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Data Inválida! " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        buttonCadastrarLivro.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                LivroModel livros = new LivroModel();
                livros.setTitulo(textFieldTitulo.getText());
                livros.setTema(textFieldTema.getText());
                livros.setAutor(textFieldAutor.getText());
                livros.setIsbn(textFieldIsbn.getText());
                livros.setDatapublicacao(formattedTextFieldData.getText());
                livros.setQuantidade(Integer.parseInt(textFieldQuantidade.getText()));
                try {
                    LivroController livro = new LivroController();
                    JOptionPane.showMessageDialog(null, livro.salvar(livros));
                    dispose();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        buttonRetornar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Principal principal = new Principal();
                principal.setVisible(true);
                dispose();
            }
        });


    }
}
