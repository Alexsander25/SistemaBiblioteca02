package View;

import Controller.LivroController;
import Model.LivroModel;
import Repository.LivroRepository;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class ListarLivros extends JFrame{
    private LivroController livroController = new LivroController();
    private JPanel panel1;
    private JScrollPane scrollLivros;
    private JTable tableCatalogo;
    private JButton buttonApagar;
    private JButton buttonRetornar;

    public ListarLivros(){
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(panel1);
        this.setSize(640, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        tableCatalogo.setAutoCreateRowSorter(true);
        ListaDeLivros livrosTabela = new ListaDeLivros();
        tableCatalogo.setModel(livrosTabela);
        buttonApagar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int linhaSelecionada = tableCatalogo.getSelectedRow();
                if(linhaSelecionada != -1) {
                    Long idLivroSelecionado = Long.parseLong(tableCatalogo.getValueAt(linhaSelecionada,0).toString());
                    try {
                        JOptionPane.showMessageDialog(null, livroController.deletar(idLivroSelecionado));
                        ListaDeLivros livroDisponiveis = new ListaDeLivros();
                        tableCatalogo.setModel(livroDisponiveis);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Selecione o livro que deseja excluir");
                }
            }
        });
        buttonRetornar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Principal principal = new Principal();
                principal.setVisible(true);
                dispose();
            }
        });
    }

    private static class ListaDeLivros extends AbstractTableModel {
        private LivroRepository livroRepository = new LivroRepository();
        private final String[] linhaLivro = new String[] {"ID", "Título", "Autor", "Tema", "ISBN", "Quantidade", "Data de Publicação"};
        private List<LivroModel> listaLivros = livroRepository.buscarTodos();

        @Override
        public int getRowCount() {
            return listaLivros.size();
        }

        @Override
        public int getColumnCount() {
            return linhaLivro.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            LivroModel livroTabela = listaLivros.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> livroTabela.getIdLivro();
                case 1 -> livroTabela.getTitulo();
                case 2 -> livroTabela.getAutor();
                case 3 -> livroTabela.getTema();
                case 4 -> livroTabela.getIsbn();
                case 5 -> livroTabela.getQuantidade();
                case 6 -> livroTabela.getDatapublicacao();
                default -> "-";
            };
        }
        @Override
        public String getColumnName(int columnIndex){
            return linhaLivro[columnIndex];
        }
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if(getValueAt(0,columnIndex) != null){
                return getValueAt(0, columnIndex).getClass();
            }else {
                return Object.class;
            }
        }
    }
}
