package View;

import Controller.UsuarioController;
import Model.UsuarioModel;
import Repository.UsuarioRepository;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class ListarUsuarios extends JFrame{
    private UsuarioController usuarioController = new UsuarioController();
    private JPanel panel1;
    private JTable tableUsuarios;
    private JScrollPane scrollUsuario;
    private JButton excluirButton;
    private JButton retornarButton;

    public ListarUsuarios(){
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(panel1);
        this.setSize(640, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        ListaDeUsuarios listaDeUsuarios = new ListaDeUsuarios();
        tableUsuarios.setModel(listaDeUsuarios);
        tableUsuarios.setAutoCreateRowSorter(true);
        excluirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int linhaSelecionada = tableUsuarios.getSelectedRow();
                if(linhaSelecionada != -1) {
                    Long idUsuarioSelecionado = Long.parseLong(tableUsuarios.getValueAt(linhaSelecionada,0).toString());
                    try {
                        JOptionPane.showMessageDialog(null, usuarioController.deletar(idUsuarioSelecionado));
                        ListaDeUsuarios usuario = new ListaDeUsuarios();
                        tableUsuarios.setModel(usuario);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Selecione para excluir");
                }
            }
        });
        retornarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Principal principal = new Principal();
                principal.setVisible(true);
                dispose();
            }
        });
    }
    private static class ListaDeUsuarios extends AbstractTableModel {
        private UsuarioRepository usuarioRepository = new UsuarioRepository();
        private final String[] linhaUsuario = new String[] {"ID", "Nome", "Sexo", "Celular", "Email"};
        private List<UsuarioModel> listaUsuarios = usuarioRepository.buscarTodos();

        @Override
        public int getRowCount() {
            return listaUsuarios.size();
        }

        @Override
        public int getColumnCount() {
            return linhaUsuario.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            UsuarioModel usuario = listaUsuarios.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> usuario.getIdUsuario();
                case 1 -> usuario.getNome();
                case 2 -> usuario.getSexo();
                case 3 -> usuario.getCelular();
                case 4 -> usuario.getEmail();
                default -> "-";
            };
        }


        @Override
        public String getColumnName(int columnIndex){
            return linhaUsuario[columnIndex];
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if(getValueAt(0,columnIndex) != null){
                return getValueAt(0, columnIndex).getClass();
            }else {
                return Object.class;
            }
        }

    }
}
