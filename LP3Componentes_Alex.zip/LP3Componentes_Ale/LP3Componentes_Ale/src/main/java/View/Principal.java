package View;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal extends JFrame{
    private JPanel panel1;
    private JPanel jpanePrincipal;
    private JLabel jlabelTitle;
    private JButton cadastrarLivrosButton;
    private JButton registrarUsuarioButton;
    private JButton catalogoButton;
    private JButton listaDeUsuariosButton;

    public Principal() {
    this.setTitle("Sistema de Biblioteca");
    this.setContentPane(panel1);
    this.setSize(640,480);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setVisible(true);

    cadastrarLivrosButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            CadastrarLivrosView catalogoLivrosView = new CadastrarLivrosView();
            catalogoLivrosView.setVisible(true);
            dispose();
        }
    });
        catalogoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ListarLivros livrosbuscados = new ListarLivros();
                livrosbuscados.setVisible(true);
                dispose();
            }
        });
        registrarUsuarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegistrarUsuarioView usuario = new RegistrarUsuarioView();
                usuario.setVisible(true);
                dispose();
            }
        });
        listaDeUsuariosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ListarUsuarios usuario = new ListarUsuarios();
                usuario.setVisible(true);
                dispose();
            }
        });
}
}
