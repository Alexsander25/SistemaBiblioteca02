package View;

import Controller.UsuarioController;
import Model.UsuarioModel;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;

public class RegistrarUsuarioView extends JFrame{
    private JPanel panel1;
    private JTextField textFieldNome;
    private JRadioButton masculinoRadioButton;
    private JRadioButton femininoRadioButton;
    private JRadioButton outrosRadioButton;
    private JButton voltarButton;
    private JButton salvarButton;
    private JFormattedTextField formattedTextFieldCelular;
    private JTextField textFieldEmail;
    private JTextField textField1;

    public RegistrarUsuarioView() {
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(panel1);
        this.setSize(640, 480);
        this.setVisible(true);
        try {
            MaskFormatter celular = new MaskFormatter("(##)#########");
            celular.install(formattedTextFieldCelular);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Número de celular Inválido " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        ButtonGroup opcao = new ButtonGroup();
        opcao.add(masculinoRadioButton);
        opcao.add(femininoRadioButton);
        opcao.add(outrosRadioButton);
        salvarButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                UsuarioModel usuarios = new UsuarioModel();
                usuarios.setNome(textFieldNome.getText());
                if (masculinoRadioButton.isSelected()) {
                    usuarios.setSexo("Masculino");
                } else if (femininoRadioButton.isSelected()) {
                    usuarios.setSexo("Feminino");
                } else if (outrosRadioButton.isSelected()) {
                    usuarios.setSexo("Não Definido");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecione uma opção!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                usuarios.setCelular(formattedTextFieldCelular.getText());
                String email = textFieldEmail.getText();
                if (!email.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                    JOptionPane.showMessageDialog(null, "Email inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                usuarios.setEmail(email);
                try {
                    UsuarioController usuarioController = new UsuarioController();
                    String mensagem = usuarioController.salvar(usuarios);
                    JOptionPane.showMessageDialog(null, mensagem, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro" + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }


            }
        });
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Principal principal = new Principal();
                principal.setVisible(true);
                dispose();
            }
        });
    }
}
